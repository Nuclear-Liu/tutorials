Moka7 Project

for convenience the source files are included into two projects both containing also a demo program.

- A NetBeans 4.7 project called Moka7-NetBeans.
- A Eclipse Kepler project called Moka7-Eclipse.

The projects are ABSOLUTLY THE SAME and contain the SAME SOURCE FILES.

Use the one that you like.

Moka7 is part of Snap7 and share its license model.